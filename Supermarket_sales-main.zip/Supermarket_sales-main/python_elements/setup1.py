from setuptools import setup, find_packages

setup(
    name="plotly-express",
    version="0.4.1",
    description="Simple description",
    packages=find_packages(),
    install_requires=['openpyxl'],
)

