from setuptools import setup, find_packages

setup(
    name="pandas",
    version="2.2.0",
    description="Simple description",
    packages=find_packages(),
    install_requires=['openpyxl'],
)

